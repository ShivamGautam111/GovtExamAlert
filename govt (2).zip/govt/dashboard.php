<?php
session_start();
$host = "localhost";
$username = "root";
$password = "";
$database = "govt_exams";

$conn = new mysqli($host, $username, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$qualification = "";
if (isset($_GET['qualification'])) {
    $qualification = $_GET['qualification'];
}

$sql = "SELECT * FROM government_exams WHERE required_qualification LIKE '%$qualification%'";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Government Exam Finder</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            margin: 0;
            padding: 0;
        }

        /* Navigation Bar Styling */
        .navbar {
            display: flex;
            justify-content: space-between;
            background-color: #333;
            padding: 10px 20px;
            color: white;
        }

        .navbar a {
            text-decoration: none;
            color: white;
            padding: 10px 20px;
            font-size: 16px;
        }

        .navbar a:hover {
            background-color: #575757;
        }

        .container {
            width: 80%;
            margin: 0 auto;
            text-align: center;
        }

        h1 {
            color: #333;
        }

        form {
            margin-bottom: 30px;
        }

        input[type="text"] {
            padding: 10px;
            font-size: 16px;
            width: 300px;
            margin-right: 10px;
        }

        button {
            padding: 10px 20px;
            font-size: 16px;
            cursor: pointer;
            background-color: #007BFF;
            color: white;
            border: none;
            border-radius: 5px;
        }

        button:hover {
            background-color: #0056b3;
        }

        .exam-list {
            text-align: left;
            margin-top: 20px;
        }

        .exam-list ul {
            list-style-type: none;
            padding: 0;
        }

        .exam-list li {
            background-color: #fff;
            padding: 15px;
            margin-bottom: 10px;
            border-radius: 8px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        .exam-list h3 {
            margin: 0;
            color: #007BFF;
        }
    </style>
</head>
<body>

    <!-- Navigation Bar -->
    <div class="navbar">
        <a href="#"></a>
        <a href="#"></a>
        <a href="#"></a>
        <a href="logout.php">Logout</a>
    </div>

    <div class="container">
        <h1>Find Government Exams Based on Your Qualification</h1>

        <form action="" method="GET">
            <label for="qualification">Select Qualification:</label>
            <select id="qualification" name="qualification" style="width: 200px;">
                <option value="">---Choose Qualification---</option>
                <option value="Graduate">Graduate</option>
                <option value="12th Pass">12th Pass</option>
                <option value="10th Pass">10th Pass</option>
            </select>
            <input type="submit" value="Search">
        </form>

        <div class="exam-list">
            <?php if ($result->num_rows > 0): ?>
                <ul>
                    <?php while($row = $result->fetch_assoc()): ?>
                        <li>
                            <h3><?php echo $row['exam_name']; ?></h3>
                            <p><strong>Eligibility Criteria:</strong> <?php echo $row['eligibility_criteria']; ?></p>
                            <p><strong>Details:</strong> <?php echo $row['exam_details']; ?></p>
                        </li>
                    <?php endwhile; ?>
                </ul>
            <?php else: ?>
                <p>No exams found for the specified qualification.</p>
            <?php endif; ?>
        </div>
    </div>

</body>
</html>

<?php
$conn->close();
?>
