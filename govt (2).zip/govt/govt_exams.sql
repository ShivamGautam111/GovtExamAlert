-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 30, 2025 at 09:44 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `govt_exams`
--

-- --------------------------------------------------------

--
-- Table structure for table `government_exams`
--

CREATE TABLE `government_exams` (
  `id` int(11) NOT NULL,
  `exam_name` varchar(255) NOT NULL,
  `required_qualification` varchar(255) NOT NULL,
  `exam_details` text DEFAULT NULL,
  `eligibility_criteria` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `government_exams`
--

INSERT INTO `government_exams` (`id`, `exam_name`, `required_qualification`, `exam_details`, `eligibility_criteria`) VALUES
(1, 'SSC Combined Graduate Level (CGL)', 'Graduate', 'Conducted by SSC for various posts in government departments.', 'Candidates must have a bachelor\'s degree from a recognized university.'),
(2, 'SSC Combined Higher Secondary Level (CHSL)', '12th Pass', 'Conducted by SSC for posts like LDC, DEO, etc.', 'Candidates must have passed 12th standard or equivalent from a recognized board.'),
(3, 'RRB NTPC', '12th Pass', 'Conducted by Railway Recruitment Boards for various non-technical posts.', 'Candidates must have passed 12th standard or equivalent from a recognized board.'),
(4, 'IBPS Clerk', 'Graduate', 'Conducted by IBPS for clerical posts in public sector banks.', 'Candidates must have a bachelor\'s degree from a recognized university.'),
(5, 'UPSC Civil Services Examination', 'Graduate', 'Conducted by UPSC for IAS, IPS, IFS, etc.', 'Candidates must have a bachelor\'s degree from a recognized university.'),
(6, 'UPSC Civil Services Examination', 'Graduate', 'Conducted by UPSC for recruitment to various civil services including IAS, IPS, IFS.', 'Candidates must have a bachelor\'s degree from a recognized university.'),
(7, 'SSC Combined Graduate Level (CGL)', 'Graduate', 'Conducted by SSC for various posts in government departments.', 'Candidates must have a bachelor\'s degree from a recognized university.'),
(8, 'SSC Combined Higher Secondary Level (CHSL)', '12th Pass', 'Conducted by SSC for posts like LDC, DEO, etc.', 'Candidates must have passed 12th standard or equivalent from a recognized board.'),
(9, 'RRB NTPC', '12th Pass', 'Conducted by Railway Recruitment Boards for various non-technical posts.', 'Candidates must have passed 12th standard or equivalent from a recognized board.'),
(10, 'IBPS Clerk', 'Graduate', 'Conducted by IBPS for clerical posts in public sector banks.', 'Candidates must have a bachelor\'s degree from a recognized university.'),
(11, 'IBPS PO', 'Graduate', 'Conducted by IBPS for probationary officer posts in public sector banks.', 'Candidates must have a bachelor\'s degree from a recognized university.'),
(12, 'SBI Clerk', 'Graduate', 'Conducted by State Bank of India for clerical posts.', 'Candidates must have a bachelor\'s degree from a recognized university.'),
(13, 'SBI PO', 'Graduate', 'Conducted by State Bank of India for probationary officer posts.', 'Candidates must have a bachelor\'s degree from a recognized university.'),
(14, 'RRB Group D', '10th Pass', 'Conducted by Railway Recruitment Boards for various posts in Indian Railways.', 'Candidates must have passed 10th standard or ITI from a recognized institution.'),
(15, 'RRB ALP', '10th Pass', 'Conducted by Railway Recruitment Boards for Assistant Loco Pilot posts.', 'Candidates must have passed 10th standard or ITI from a recognized institution.'),
(16, 'RRB JE', 'Diploma', 'Conducted by Railway Recruitment Boards for Junior Engineer posts.', 'Candidates must have a diploma in engineering from a recognized institution.'),
(17, 'RRB Ministerial & Isolated Categories', 'Graduate', 'Conducted by Railway Recruitment Boards for various ministerial and isolated category posts.', 'Candidates must have a bachelor\'s degree from a recognized university.'),
(18, 'IBPS RRB PO', 'Graduate', 'Conducted by IBPS for probationary officer posts in Regional Rural Banks.', 'Candidates must have a bachelor\'s degree from a recognized university.'),
(19, 'IBPS RRB Clerk', 'Graduate', 'Conducted by IBPS for clerical posts in Regional Rural Banks.', 'Candidates must have a bachelor\'s degree from a recognized university.'),
(20, 'LIC AAO', 'Graduate', 'Conducted by Life Insurance Corporation of India for Assistant Administrative Officer posts.', 'Candidates must have a bachelor\'s degree from a recognized university.'),
(21, 'LIC ADO', '12th Pass', 'Conducted by Life Insurance Corporation of India for Apprentice Development Officer posts.', 'Candidates must have passed 12th standard or equivalent from a recognized board.'),
(22, 'RBI Assistant', 'Graduate', 'Conducted by Reserve Bank of India for Assistant posts.', 'Candidates must have a bachelor\'s degree from a recognized university.'),
(23, 'RBI Grade B', 'Graduate', 'Conducted by Reserve Bank of India for Grade B officer posts.', 'Candidates must have a bachelor\'s degree from a recognized university.'),
(24, 'SEBI Grade A', 'Graduate', 'Conducted by Securities and Exchange Board of India for Assistant Manager posts.', 'Candidates must have a bachelor\'s degree from a recognized university.'),
(25, 'NABARD Grade A', 'Graduate', 'Conducted by National Bank for Agriculture and Rural Development for Assistant Manager posts.', 'Candidates must have a bachelor\'s degree from a recognized university.'),
(26, 'NABARD Grade B', 'Graduate', 'Conducted by National Bank for Agriculture and Rural Development for Manager posts.', 'Candidates must have a bachelor\'s degree from a recognized university.'),
(27, 'OICL AO', 'Graduate', 'Conducted by Oriental Insurance Company Limited for Administrative Officer posts.', 'Candidates must have a bachelor\'s degree from a recognized university.'),
(28, 'NIACL AO', 'Graduate', 'Conducted by New India Assurance Company Limited for Administrative Officer posts.', 'Candidates must have a bachelor\'s degree from a recognized university.'),
(29, 'ESIC UDC', '12th Pass', 'Conducted by Employees\' State Insurance Corporation for Upper Division Clerk posts.', 'Candidates must have passed 12th standard or equivalent from a recognized board.'),
(30, 'ESIC MTS', '10th Pass', 'Conducted by Employees\' State Insurance Corporation for Multi-Tasking Staff posts.', 'Candidates must have passed 10th standard or equivalent from a recognized board.'),
(31, 'ESIC Stenographer', '12th Pass', 'Conducted by Employees\' State Insurance Corporation for Stenographer posts.', 'Candidates must have passed 12th standard or equivalent from a recognized board.'),
(32, 'SSC MTS', '10th Pass', 'Conducted by SSC for Multi-Tasking Staff posts in various government departments.', 'Candidates must have passed 10th standard or equivalent from a recognized board.'),
(33, 'SSC Stenographer', '12th Pass', 'Conducted by SSC for Stenographer posts in various government departments.', 'Candidates must have passed 12th standard or equivalent from a recognized board.'),
(34, 'SSC GD Constable', '10th Pass', 'Conducted by SSC for General Duty Constable posts in various forces.', 'Candidates must have passed 10th standard or equivalent from a recognized board.'),
(35, 'SSC JHT', 'Graduate', 'Conducted by SSC for Junior Hindi Translator posts.', 'Candidates must have a bachelor\'s degree from a recognized university.'),
(36, 'SSC JE', 'Diploma', 'Conducted by SSC for Junior Engineer posts in various government departments.', 'Candidates must have a diploma in engineering from a recognized institution.'),
(37, 'SSC CPO', 'Graduate', 'Conducted by SSC for Central Police Organization posts.', 'Candidates must have a bachelor\'s degree from a recognized university.'),
(38, 'SSC CHSL', '12th Pass', 'Conducted by SSC for Combined Higher Secondary Level posts.', 'Candidates must have passed 12th standard or equivalent from a recognized board.'),
(39, 'SSC CGL', 'Graduate', 'Conducted by SSC for Combined Graduate Level posts.', 'Candidates must have a bachelor\'s degree from a recognized university.'),
(40, 'UPSC NDA', '12th Pass', 'Conducted by UPSC for National Defence Academy entry.', 'Candidates must have passed 12th standard or equivalent from a recognized board.'),
(41, 'UPSC CDS', 'Graduate', 'Conducted by UPSC for Combined Defence Services entry.', 'Candidates must have a bachelor\'s degree from a recognized university.'),
(42, 'UPSC CAPF', 'Graduate', 'Conducted by UPSC for Central Armed Police Forces entry.', 'Candidates must have a bachelor\'s degree from a recognized university.');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `qualification` varchar(50) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `qualification`, `created_at`) VALUES
(1, 'pratap', '123456@gmail.com', '$2y$10$dv1XsIXIBJ3nKl3dR3DL9eQvG4DT3T7qw10pmU8/liYdD03pUAzx2', '12th', '2025-01-30 07:59:34');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `government_exams`
--
ALTER TABLE `government_exams`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `government_exams`
--
ALTER TABLE `government_exams`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
